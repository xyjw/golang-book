package aa

var A_string = "Hello go!"

var numbers int = 10

type A_struct struct {
	Name string
}
