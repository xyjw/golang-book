package mpb

var MyVariable int = 666
