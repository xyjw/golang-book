package mpb

import "fmt"

func Get_data(){
	fmt.Println("这是自动包mpb的导出标识符Get_data")
}
