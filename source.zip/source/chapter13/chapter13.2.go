package main

// 导入内置包fmt
import "fmt"

func main() {
	// 调用内置包的函数Println()
	fmt.Println("hello world")
}
