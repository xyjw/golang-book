package main

import "fmt"

func main() {
	//var a string
	//var b string
	//a = "hello world\nGo"
	//b = `hello
	//	\n
	//	world`
	//fmt.Printf("双引号的字符串：%v\n", a)
	//fmt.Printf("反引号的字符串：%v\n", b)

	fmt.Println("Tom\tJack")
	fmt.Println("你\n好")
	fmt.Println("E:\\go\\chapter3.6.go")
	fmt.Println("Alice说:\"I love golang\"")
	fmt.Println("Hello\rworld")
}